import { Elysia } from "elysia";
import * as authController from "../controllers/auth.controller";

export const authRoutes = new Elysia()
  /**
   * Ejercicio: definir las rutas correspondientes, ambas deben ser POST.
   */