# El nodo principal del player es un CharacterBody2D (un cuerpo capaz de moverse y colisionar)
extends CharacterBody2D

var SPEED : float = 300
var JUMP_FORCE : float = -500
var gravity : float = 980

@export var checkpoint_position = Vector2(0,0)

#La funcion _ready se corre cuando se carga la escena.
func _ready() -> void:
	checkpoint_position = global_position

#La funcion _physics_process se corre todos los frames. De hecho, delta es el tiempo transcurrido entre frames.
func _physics_process(delta: float) -> void:
	
	#Gravedad, aceleracion hacia abajo
	velocity.y += gravity*delta
	
	#Para el salto
	if Input.is_action_pressed("S_key") and Input.is_action_just_pressed("ui_accept"):				#esta linea de aca nos permite bajar de las plataformas finitas.
		position.y += 1
	elif Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_FORCE
	#Tip: pueden crear sus propios inputs en Proyecto/Project settings/Mapa de entrada/Agregar accion nueva
	
	#Para el movimiento del jugador
	var direction: int = Input.get_axis("A_key", "D_key")
	velocity.x = direction * SPEED
	#Tip: si su juego no tiene gravedad, pueden usar "Inpt.get_vector", que es un Vector2 y darle las 4 direcciones (LEFT,RiGHT,UP,DOWN)
	
	if Input.is_action_pressed("S_key") and Input.is_action_just_pressed("ui_accept"):
		position.y += 5
	
	# move_and_slide es el encargado de mover al cuerpo segun la variable velocity
	move_and_slide()

#Esta funcion no la llaa nunca el jugador, son los enemigos los que le dicen al jugador que se haga daño. 
func hurt() -> void:
	global_position = checkpoint_position
