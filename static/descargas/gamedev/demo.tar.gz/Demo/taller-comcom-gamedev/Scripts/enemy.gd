# El enemigo se mueve (distinto al player, pero se mueve y colisiona), por lo que es un CharacterBody2D
extends CharacterBody2D

var SPEED : float = 100
var direction = 1
var rc_left : RayCast2D			#detecta el piso a la izquierda.
var rc_right : RayCast2D		#detecta el piso a la derecha.
var gravity : float = 980

#La funcion _ready se corre cuando se carga la escena.
func _ready() -> void:
	rc_left = $LeftCast
	rc_right = $RightCast

#La funcion _physics_process se corre cada frame.
func _physics_process(delta: float) -> void:
	
	# Aplicamos movimientos acordemente
	velocity.x = direction*SPEED
	velocity.y += gravity*delta
	
	# Chequeamos si se llego al final derecho de la plataforma
	if direction > 0 and (not rc_right.is_colliding() or is_on_wall()):
		direction = -direction
		position.x -= 2
	# Lo mismo, pero del lado izquierdo
	elif direction < 0 and (not rc_left.is_colliding() or is_on_wall()):
		direction = -direction
		position.x += 2
	
	# Fijense como el enemigo, si bien se mueve distinto, tambien utiliza move_and_slide porque es un CharacterBody2D
	move_and_slide()

func hurt() -> void:
	# queue_free es un metodo comun a todos los nodos, es la forma de "autoeliminarse" de la escena
	queue_free()

#Si entra el jugador a el area, le hace daño
func _on_hurt_box_body_entered(body: Node2D) -> void:
	body.hurt()
