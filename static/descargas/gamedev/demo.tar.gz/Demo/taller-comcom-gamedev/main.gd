extends Node2D

#Si el jugador sale de los player bounds, se muere y vuelve al checkpoint
func _on_area_2d_body_entered(body: Node2D) -> void:
	
	# Esto en realidad abarca tanto jugadores como enemigos, ya que ambos son CharacterBody2D, y ambos tienen un metodo hurt
	if body.get_class() == "CharacterBody2D":
		body.hurt()
